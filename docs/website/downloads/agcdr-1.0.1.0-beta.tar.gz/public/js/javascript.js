
// AGCDR: General Javascript functions library
// Copyright 2011 Stuart Benjamin Ford, all rights reserved

