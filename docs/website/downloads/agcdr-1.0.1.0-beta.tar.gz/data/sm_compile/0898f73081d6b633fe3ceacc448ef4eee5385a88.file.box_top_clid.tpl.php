<?php /* Smarty version Smarty-3.0.7, created on 2011-03-08 11:58:32
         compiled from "/opt/agcdr/public/../application/views/reports/box_top_clid.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7591763664d7619e882eaa3-86521481%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0898f73081d6b633fe3ceacc448ef4eee5385a88' => 
    array (
      0 => '/opt/agcdr/public/../application/views/reports/box_top_clid.tpl',
      1 => 1299252592,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7591763664d7619e882eaa3-86521481',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<div class="title">Top caller IDs</div>

<div class="content">

	<?php if (count($_smarty_tpl->getVariable('numbers')->value)>0){?>

		<table class="basicreport" width="100%">
		
			<thead><tr>
				<th>Caller ID</th>
				<th>Count</th>
			</tr></thead>
			
			<body>
			
			<?php  $_smarty_tpl->tpl_vars['count'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['number'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('numbers')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['count']->key => $_smarty_tpl->tpl_vars['count']->value){
 $_smarty_tpl->tpl_vars['number']->value = $_smarty_tpl->tpl_vars['count']->key;
?>
			
				<tr>
					<td><?php echo $_smarty_tpl->tpl_vars['number']->value;?>
</td>
					<td align="center"><?php echo $_smarty_tpl->tpl_vars['count']->value;?>
</td>
				</tr>
			
			<?php }} ?>
			
			</body>
		
		</table>
		
	<?php }else{ ?>
	
		<p>No statistics were returned by this overview.</p>
	
	<?php }?>

</div>
