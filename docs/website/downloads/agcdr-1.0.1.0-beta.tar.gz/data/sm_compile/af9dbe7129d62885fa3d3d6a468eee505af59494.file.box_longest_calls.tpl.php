<?php /* Smarty version Smarty-3.0.7, created on 2011-03-08 11:44:40
         compiled from "/opt/agcdr/public/../application/views/index/box_longest_calls.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6688241834d7616a8b611d1-33753697%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'af9dbe7129d62885fa3d3d6a468eee505af59494' => 
    array (
      0 => '/opt/agcdr/public/../application/views/index/box_longest_calls.tpl',
      1 => 1299584518,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6688241834d7616a8b611d1-33753697',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include '/opt/agcdr/application/libraries/Smarty-3.0.7/libs/plugins/modifier.date_format.php';
?>

<div class="title">Longest calls</div>

<div class="content">

	<?php if (count($_smarty_tpl->getVariable('cdrs')->value)>0){?>

		<table class="basicreport" width="100%">
		
			<thead><tr>
				<th>Date</th>
				<th>Source</th>
				<th>Destination</th>
				<th>Duration</th>
			</tr></thead>
			
			<body>
			
			<?php  $_smarty_tpl->tpl_vars['cdr'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['uniqueid'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('cdrs')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['cdr']->key => $_smarty_tpl->tpl_vars['cdr']->value){
 $_smarty_tpl->tpl_vars['uniqueid']->value = $_smarty_tpl->tpl_vars['cdr']->key;
?>
			
				<tr onmouseover="$(this).toggleClass('grey');" onmouseout="$(this).toggleClass('grey');" onclick="window.location='/cdr/view/?uid=<?php echo $_smarty_tpl->tpl_vars['uniqueid']->value;?>
';">
					<td><?php echo smarty_modifier_date_format(strtotime($_smarty_tpl->tpl_vars['cdr']->value['calldate']),"%d/%m/%Y");?>
</td>
					<td><?php echo $_smarty_tpl->tpl_vars['cdr']->value['src'];?>
</td>
					<td><?php echo $_smarty_tpl->tpl_vars['cdr']->value['dst'];?>
</td>
					<td><?php echo $_smarty_tpl->tpl_vars['cdr']->value['formatted_duration'];?>
</td>
				</tr>
			
			<?php }} ?>
			
			</body>
		
		</table>
		
	<?php }else{ ?>
	
		<p>There are no CDRs present in the database.</p>
	
	<?php }?>

</div>
