<?php /* Smarty version Smarty-3.0.7, created on 2011-03-01 16:07:34
         compiled from "/opt/agcdr/application/views/shared/htmlfooter.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14866945524d6d19c671eb38-52011288%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '37d3e57b0aaadda67784197c0fd6e4ed003c7977' => 
    array (
      0 => '/opt/agcdr/application/views/shared/htmlfooter.tpl',
      1 => 1298894960,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14866945524d6d19c671eb38-52011288',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include '/opt/agcdr/application/libraries/Smarty-3.0.7/libs/plugins/modifier.date_format.php';
?>
</div> <!--  frame -->

<p id="copyright">Version <?php echo @VERSION;?>
, &copy; <?php echo smarty_modifier_date_format(time(),"%Y");?>
 <a href="http://www.heddonconsulting.com/">Heddon Consulting Ltd.</a>, all rights reserved.</p>

<script type="text/javascript" src="/js/jquery.ready-min.js"></script>

</body>
</html>