<?php /* Smarty version Smarty-3.0.7, created on 2011-03-01 16:07:34
         compiled from "/opt/agcdr/application/views/shared/htmlheader.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12315771594d6d19c66d9d79-99210797%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ec455803960fb62b0ce4b9a8e89b0be8f8783c43' => 
    array (
      0 => '/opt/agcdr/application/views/shared/htmlheader.tpl',
      1 => 1298994080,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12315771594d6d19c66d9d79-99210797',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
	
<html lang="en">

<head>

	<title><?php if ($_smarty_tpl->getVariable('title')->value){?><?php echo $_smarty_tpl->getVariable('title')->value;?>
<?php }?></title>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="version" name="<?php echo @VERSION;?>
" />
	
	<!-- General CSS and javascript -->
	<link rel="stylesheet" type="text/css" media="all" href="/css/stylesheet-min.css" />
	<link rel="stylesheet" type="text/css" media="print" href="/css/print-min.css" />
	<script type="text/javascript" src="/js/javascript-min.js"></script>
	<script type="text/javascript" src="/js/modernizr-1.6-min.js"></script>
	
	<!-- jQuery -->
	<link rel="stylesheet" type="text/css" href="/libraries/jquery-ui-1.8.10.custom/css/cupertino/jquery-ui-1.8.10.custom.css"/>
	<script type="text/javascript" src="/libraries/jquery-ui-1.8.10.custom/js/jquery-1.4.4.min.js"></script>
	<script type="text/javascript" src="/libraries/jquery-ui-1.8.10.custom/js/jquery-ui-1.8.10.custom.min.js"></script>
	<script type="text/javascript" src="/libraries/DataTables-1.7.5/media/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/js/jquery.dataTables.extensions-min.js"></script>
	<link rel="stylesheet" type="text/css" href="/css/demo_table_jui-min.css"/>
	
	<!-- Superfish navigation -->
	<link rel="stylesheet" media="screen" href="/css/superfish-min.css" /> 
	<link rel="stylesheet" media="screen" href="/css/superfish-navbar-min.css" />
	<script type="text/javascript" src="/libraries/superfish-1.4.8/js/superfish.js"></script>
	<script type="text/javascript" src="/libraries/superfish-1.4.8/js/hoverIntent.js"></script>

</head>

<body>

<?php if (defined("DEVINFO")){?><div id="devinfo" onclick="this.style.display='none';"><?php echo @DEVINFO;?>
</div><?php }?>

<div id="frame">

<h1><?php echo @LONG_TITLE;?>
</h1>

<?php $_template = new Smarty_Internal_Template('shared/navigation.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>
