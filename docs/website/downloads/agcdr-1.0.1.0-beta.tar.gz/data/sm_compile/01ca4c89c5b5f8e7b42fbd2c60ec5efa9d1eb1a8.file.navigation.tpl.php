<?php /* Smarty version Smarty-3.0.7, created on 2011-03-01 16:07:34
         compiled from "/opt/agcdr/application/views/shared/navigation.tpl" */ ?>
<?php /*%%SmartyHeaderCode:896705064d6d19c671d021-78375144%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '01ca4c89c5b5f8e7b42fbd2c60ec5efa9d1eb1a8' => 
    array (
      0 => '/opt/agcdr/application/views/shared/navigation.tpl',
      1 => 1298891007,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '896705064d6d19c671d021-78375144',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
