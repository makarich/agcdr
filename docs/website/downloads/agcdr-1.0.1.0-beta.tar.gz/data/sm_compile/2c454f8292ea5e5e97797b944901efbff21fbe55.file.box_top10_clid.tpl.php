<?php /* Smarty version Smarty-3.0.7, created on 2011-03-03 17:15:40
         compiled from "/opt/agcdr/public/../application/views/index/box_top10_clid.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6469529014d6fccbc9e8d63-33217385%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2c454f8292ea5e5e97797b944901efbff21fbe55' => 
    array (
      0 => '/opt/agcdr/public/../application/views/index/box_top10_clid.tpl',
      1 => 1299171508,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6469529014d6fccbc9e8d63-33217385',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<div class="title">Top 10 caller IDs</div>

<div class="content">



</div>
