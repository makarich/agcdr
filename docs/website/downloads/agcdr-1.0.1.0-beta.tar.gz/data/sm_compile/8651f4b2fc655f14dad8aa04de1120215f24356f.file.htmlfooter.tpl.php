<?php /* Smarty version Smarty-3.0.7, created on 2011-03-16 12:13:06
         compiled from "/opt/agcdr/public/../application/views/shared/htmlfooter.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6443902174d80a9525a4e42-13838458%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8651f4b2fc655f14dad8aa04de1120215f24356f' => 
    array (
      0 => '/opt/agcdr/public/../application/views/shared/htmlfooter.tpl',
      1 => 1300274966,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6443902174d80a9525a4e42-13838458',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include '/opt/agcdr/application/libraries/Smarty-3.0.7/libs/plugins/modifier.date_format.php';
?>
</div> <!--  frame -->

<p id="copyright">
	Version <?php echo @VERSION;?>
,
	&copy; <?php echo smarty_modifier_date_format(time(),"%Y");?>

	<a href="http://www.stuartford.me.uk/">Stuart Benjamin Ford</a>, all rights reserved.
</p>

<script type="text/javascript" src="/js/jquery.ready-min.js"></script>

</body>
</html>
