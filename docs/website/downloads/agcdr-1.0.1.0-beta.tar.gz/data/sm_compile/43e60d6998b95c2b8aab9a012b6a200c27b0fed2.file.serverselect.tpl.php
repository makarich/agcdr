<?php /* Smarty version Smarty-3.0.7, created on 2011-03-10 17:42:44
         compiled from "/opt/agcdr/public/../application/views/shared/serverselect.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6558137144d790d94e59838-07952190%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '43e60d6998b95c2b8aab9a012b6a200c27b0fed2' => 
    array (
      0 => '/opt/agcdr/public/../application/views/shared/serverselect.tpl',
      1 => 1299778875,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6558137144d790d94e59838-07952190',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<div id="serverselect">

	<form method="POST" action="/" name="serverswitch">

	Select database server:

	<select name="switchto" id="switchto" onchange="document.serverswitch.submit();" <?php if (count($_SESSION['servers'])<=1){?>disabled<?php }?>>
	<?php  $_smarty_tpl->tpl_vars['server'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['hostname'] = new Smarty_Variable;
 $_from = $_SESSION['servers']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['server']->key => $_smarty_tpl->tpl_vars['server']->value){
 $_smarty_tpl->tpl_vars['hostname']->value = $_smarty_tpl->tpl_vars['server']->key;
?>
		<option value="<?php echo $_smarty_tpl->tpl_vars['hostname']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['hostname']->value==$_SESSION['server']){?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['server']->value['description'];?>
</option>
	<?php }} ?>
	</select>
	
	</form>

</div>
