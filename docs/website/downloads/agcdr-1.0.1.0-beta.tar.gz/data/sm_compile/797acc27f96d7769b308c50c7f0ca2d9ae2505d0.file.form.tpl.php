<?php /* Smarty version Smarty-3.0.7, created on 2011-03-16 14:05:02
         compiled from "/opt/agcdr/public/../application/views/search/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13570477104d80c38e9f91e1-56682541%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '797acc27f96d7769b308c50c7f0ca2d9ae2505d0' => 
    array (
      0 => '/opt/agcdr/public/../application/views/search/form.tpl',
      1 => 1300284240,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13570477104d80c38e9f91e1-56682541',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_function_icon')) include '/opt/agcdr/application/libraries/Smarty-3.0.7/libs/plugins/function.icon.php';
?>

<form method="POST" action="/search/results/" onsubmit="return validateAdvancedSearch();">

<table class="form" id="advancedsearch">

	<tbody>

		<tr id="daterow">
			<td class="label">Date range</td>
			<td class="value" nowrap>
				<input type="text" class="datepicker" name="date_from" size="12" value="<?php echo $_smarty_tpl->getVariable('date_from')->value;?>
" readonly />
				to
				<input type="text" class="datepicker" name="date_to" size="12" value="<?php echo $_smarty_tpl->getVariable('date_to')->value;?>
" readonly />
			</td>
		</tr>
	
	</tbody>
	
	<tfoot>
	
		<tr>
			<td class="buttonbar" colspan="2" nowrap>
				<button type="button" onclick="addCriteriaRow();"><?php echo smarty_function_icon(array('name'=>"add"),$_smarty_tpl);?>
&nbsp;&nbsp;Add criteria</button>
				<button type="submit"><?php echo smarty_function_icon(array('name'=>"search"),$_smarty_tpl);?>
&nbsp;&nbsp;Search</button>
			</td>
		</tr>
		
	</tfoot>

</table>

</form>



<script type="text/javascript">

// table field array (excluding date/time)
var cdrFields = {
	"clid"		: "Caller ID",
	"src"		: "Source",
	"dst"		: "Destination",
	"dcontext"	: "Context",
	"channel"	: "Channel",
	"dstchannel"	: "Destination channel",
	"lastapp"	: "Last application",
	"lastdata"	: "Last data",
	"duration"	: "Duration",
	"billsec"	: "Billsec",
	"disposition"	: "Disposition",
	"amaflags"	: "AMA flags",
	"accountcode"	: "Account code",
	"userfield"	: "User field",
	"uniqueid"	: "Unique ID"
};

// add a criteria row
function addCriteriaRow() {

	// increment row count
	totalRows = totalRows + 1;

	// create row object
	newRow = $('<tr id="criteria_row_'+totalRows+'"></tr>');

	// add label cell
	$(newRow).append($('<td class="label" nowrap>Criteria '+totalRows+'</td>'));

	// create new cell
	newCell = $('<td class="value" nowrap></td>');

	// build field menu
	fieldMenu = $('<select id="field_'+totalRows+'" name="field_'+totalRows+'"></select>');
	for (var field in cdrFields) {
		$(fieldMenu).append($('<option value="'+field+'">'+cdrFields[field]+'</option>'));
	}
	$(newCell).append(fieldMenu);

	// build operator menu
	opMenu = $('<select id="operator_'+totalRows+'" name="operator_'+totalRows+'"></select>');
	$(opMenu).append($('<option value="contains">contains</option>'));
	$(opMenu).append($('<option value="equals">exactly equals</option>'));
	$(opMenu).append($('<option value="ltet">is less than or equal to</option>'));
	$(opMenu).append($('<option value="gtet">is greater than or equal to</option>'));
	$(newCell).append(opMenu);

	// add text field
	textField = $('<input type="text" id="criteria_'+totalRows+'" name="criteria_'+totalRows+'" size="20" />');
	$(newCell).append(textField);

	// add row delete button
	if (totalRows > 1) {
		cancelButton = $('<a href="javascript:void(0);" onclick="deleteCriteriaRow('+totalRows+');"><img src="/images/icons/delete.png" width="16" height="16" border="0" alt="Delete criteria" valign="top" /></a>');
		$(newCell).append(cancelButton);
	}
	
	// add cell to row and row to table
	$(newRow).append(newCell);
	$("#advancedsearch").append(newRow);

}

// delete a criteria row
function deleteCriteriaRow(rowID) {
	if (document.getElementById('criteria_row_'+rowID)) {
		$('#criteria_row_'+rowID).remove();
	}
}

// validate form
function validateAdvancedSearch() {

	// check that criteria boxes each have at least 3 characters
	for (i=1; i<=totalRows; i++) {
		if (document.getElementById('criteria_'+i)) {
			criteria = document.getElementById('criteria_'+i).value;
			if (criteria.length < 3) {
				alert("Criteria "+totalRows+" must be at least three characters in length.");
				return false;
			}
		}
	}
	
	return true;

}



// start total rows count
var totalRows = 0;

<?php if ($_smarty_tpl->getVariable('criteria')->value){?>

	// add initial criteria rows and pre-populate

	for (i=0; i<<?php echo count($_smarty_tpl->getVariable('criteria')->value);?>
; i++) {
		addCriteriaRow();
	}

	<?php  $_smarty_tpl->tpl_vars['crit'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('criteria')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['crit']->key => $_smarty_tpl->tpl_vars['crit']->value){
 $_smarty_tpl->tpl_vars['id']->value = $_smarty_tpl->tpl_vars['crit']->key;
?>
		document.getElementById('field_<?php echo $_smarty_tpl->tpl_vars['id']->value+1;?>
').value = '<?php echo $_smarty_tpl->tpl_vars['crit']->value['field'];?>
';
		document.getElementById('operator_<?php echo $_smarty_tpl->tpl_vars['id']->value+1;?>
').value = '<?php echo $_smarty_tpl->tpl_vars['crit']->value['operator'];?>
';
		document.getElementById('criteria_<?php echo $_smarty_tpl->tpl_vars['id']->value+1;?>
').value = '<?php echo $_smarty_tpl->tpl_vars['crit']->value['keywords'];?>
';
	<?php }} ?>
	
<?php }else{ ?>

	// add initial criteria row
	addCriteriaRow();
	
<?php }?>

</script>
