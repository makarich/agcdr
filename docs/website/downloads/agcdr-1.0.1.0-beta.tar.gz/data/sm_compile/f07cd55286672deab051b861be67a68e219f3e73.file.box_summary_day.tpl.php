<?php /* Smarty version Smarty-3.0.7, created on 2011-03-08 17:35:40
         compiled from "/opt/agcdr/public/../application/views/index/box_summary_day.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2662010804d7668ec854d77-88240834%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f07cd55286672deab051b861be67a68e219f3e73' => 
    array (
      0 => '/opt/agcdr/public/../application/views/index/box_summary_day.tpl',
      1 => 1299601293,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2662010804d7668ec854d77-88240834',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<div class="title">Day summary</div>

<div class="content">

	<p align="center"><img src="/images/charts/<?php echo $_smarty_tpl->getVariable('chart')->value;?>
" alt="Day summary chart" width="300" height="265"/></p>

</div>
