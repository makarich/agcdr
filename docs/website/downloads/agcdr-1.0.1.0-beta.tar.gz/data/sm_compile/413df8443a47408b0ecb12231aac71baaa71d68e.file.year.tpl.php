<?php /* Smarty version Smarty-3.0.7, created on 2011-03-09 11:30:13
         compiled from "/opt/agcdr/public/../application/views/reports/year.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15053438134d7764c5acd1d1-46105780%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '413df8443a47408b0ecb12231aac71baaa71d68e' => 
    array (
      0 => '/opt/agcdr/public/../application/views/reports/year.tpl',
      1 => 1299669752,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15053438134d7764c5acd1d1-46105780',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_function_icon')) include '/opt/agcdr/application/libraries/Smarty-3.0.7/libs/plugins/function.icon.php';
?><?php $_template = new Smarty_Internal_Template('shared/htmlheader.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>

<div id="prevnext">
	<button type="button" onclick="window.location='/<?php echo $_smarty_tpl->getVariable('controller')->value;?>
/<?php echo $_smarty_tpl->getVariable('action')->value;?>
/?year=<?php echo $_smarty_tpl->getVariable('year')->value-1;?>
';"><?php echo smarty_function_icon(array('name'=>"control_rewind_blue"),$_smarty_tpl);?>
&nbsp;&nbsp;<?php echo $_smarty_tpl->getVariable('year')->value-1;?>
</button>
	<button type="button" onclick="window.location='/<?php echo $_smarty_tpl->getVariable('controller')->value;?>
/<?php echo $_smarty_tpl->getVariable('action')->value;?>
/?year=<?php echo $_smarty_tpl->getVariable('year')->value+2;?>
';"><?php echo $_smarty_tpl->getVariable('year')->value+1;?>
&nbsp;&nbsp;<?php echo smarty_function_icon(array('name'=>"control_fastforward_blue"),$_smarty_tpl);?>
</button>
</div>

<h2><?php echo $_smarty_tpl->getVariable('year')->value;?>
</h2>
<div id="tabs">

	<ul>
		<li><a href="#tabs-overview">Overview</a></li>
		<li><a href="#tabs-calls">Calls per month</a></li>
		<li><a href="#tabs-mins">Minutes per month</a></li>
	</ul>
	
	<div id="tabs-overview">
	
		<ul id="overviewgrid">
			<?php  $_smarty_tpl->tpl_vars['box'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('boxes')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['box']->key => $_smarty_tpl->tpl_vars['box']->value){
?>
				<li id="box_<?php echo $_smarty_tpl->tpl_vars['box']->value;?>
">Loading box <?php echo $_smarty_tpl->tpl_vars['box']->value;?>
 ...</li>
			<?php }} ?>
		</ul>
	
		<div style="clear: both;"></div>
	
	</div>
	
	<div id="tabs-calls">
	
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
		
			<tr>
			
				<td align="left" valign="top">
					<img src="/images/charts/<?php echo $_smarty_tpl->getVariable('chart_calls')->value;?>
" class="greyborder" alt="Calls per month" width="700" height="350"/>
				</td>
				
				<td align="left" valign="top" width="100%" class="statistics">
					<p>Total calls: <b><?php echo $_smarty_tpl->getVariable('total_calls')->value;?>
</b></p>
					<p>Average calls per week: <b><?php echo $_smarty_tpl->getVariable('average_calls_week')->value;?>
</b></p>
					<p>Average calls per month: <b><?php echo $_smarty_tpl->getVariable('average_calls_month')->value;?>
</b></p>
				</td>
			
			</tr>
		
		</table>
	
	</div>
	
	<div id="tabs-mins">
	
		<table border="0" cellpadding="0" cellspacing="0">
		
			<tr>
			
				<td align="left" valign="top">
					<img src="/images/charts/<?php echo $_smarty_tpl->getVariable('chart_mins')->value;?>
" class="greyborder" alt="Minutes per month" width="700" height="350"/>
				</td>
				
				<td align="left" valign="top" width="100%" class="statistics">
					<p>Total minutes: <b><?php echo $_smarty_tpl->getVariable('total_mins')->value;?>
</b></p>
					<p>Average minutes per week: <b><?php echo $_smarty_tpl->getVariable('average_mins_week')->value;?>
</b></p>
					<p>Average minutes per month: <b><?php echo $_smarty_tpl->getVariable('average_mins_month')->value;?>
</b></p>
				</td>
			
			</tr>
		
		</table>
	
	</div>

</div>



<script type="text/javascript">
	
	$(function() {

		// create tabbed section
		$("#tabs").tabs();
		
		// create sortable grid
		$("#overviewgrid").sortable();
		$("#overviewgrid").disableSelection();

		// set box list
		var allBoxes = new Array(<?php echo $_smarty_tpl->getVariable('boxlist')->value;?>
);

		// load content into all boxes
		for (i=0; i<allBoxes.length; i++) {
			$("#box_"+allBoxes[i]).load('/reports/box/?box='+allBoxes[i]+"&year=<?php echo $_smarty_tpl->getVariable('year')->value;?>
");
		}
			
	});

</script>
	


<?php $_template = new Smarty_Internal_Template('shared/htmlfooter.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>
