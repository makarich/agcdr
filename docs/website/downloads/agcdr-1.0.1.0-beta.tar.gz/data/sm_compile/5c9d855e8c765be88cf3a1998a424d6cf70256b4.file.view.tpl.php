<?php /* Smarty version Smarty-3.0.7, created on 2011-03-04 17:03:01
         compiled from "/opt/agcdr/public/../application/views/cdr/view.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18459230944d711b45bf1d81-43839727%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5c9d855e8c765be88cf3a1998a424d6cf70256b4' => 
    array (
      0 => '/opt/agcdr/public/../application/views/cdr/view.tpl',
      1 => 1299258180,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18459230944d711b45bf1d81-43839727',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include '/opt/agcdr/application/libraries/Smarty-3.0.7/libs/plugins/modifier.date_format.php';
?><?php $_template = new Smarty_Internal_Template('shared/htmlheader.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>

<?php if ($_smarty_tpl->getVariable('cdr')->value->uniqueid){?>

	<h2>Call <?php echo $_smarty_tpl->getVariable('cdr')->value->uniqueid;?>
</h2>
	
	<table class="form">
	
		<tr>
			<td class="label" nowrap>Date and time</td>
			<td class="value"><?php echo smarty_modifier_date_format(strtotime($_smarty_tpl->getVariable('cdr')->value->calldate),"%d/%m/%Y %H:%M:%S");?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>Caller ID</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->clid;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>Source</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->src;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>Destination</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->dst;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>Context</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->dcontext;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>Channel</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->channel;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>Destination channel</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->dstchannel;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>Last application</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->lastapp;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>Last data</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->lastdata;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>Disposition</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->disposition;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>Duration</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->duration_formatted;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>Billable duration</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->billsecs_formatted;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>Account code</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->accountcode;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>AMA flags</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->amaflags;?>
</td>
		</tr>
		<tr>
			<td class="label" nowrap>User field</td>
			<td class="value"><?php echo $_smarty_tpl->getVariable('cdr')->value->userfield;?>
</td>
		</tr>
	
	</table>
	
<?php }else{ ?>

	<p class="ui-state-error ui-corner-all warning">The referenced caller detail record unique ID is invalid.</p>

<?php }?>

<?php $_template = new Smarty_Internal_Template('shared/htmlfooter.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>