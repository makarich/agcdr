<?php /* Smarty version Smarty-3.0.7, created on 2011-03-08 17:35:42
         compiled from "/opt/agcdr/public/../application/views/index/box_summary_week.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10253304974d7668eec3fad1-90617264%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '47b42c91b4fbaf3fc037d3d7f31e84106db26404' => 
    array (
      0 => '/opt/agcdr/public/../application/views/index/box_summary_week.tpl',
      1 => 1299601285,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10253304974d7668eec3fad1-90617264',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<div class="title">Week summary</div>

<div class="content">

	<p align="center"><img src="/images/charts/<?php echo $_smarty_tpl->getVariable('chart')->value;?>
" alt="Week summary chart" width="300" height="265"/></p>

</div>
