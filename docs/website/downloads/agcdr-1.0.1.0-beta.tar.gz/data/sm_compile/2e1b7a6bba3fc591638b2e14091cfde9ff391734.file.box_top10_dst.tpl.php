<?php /* Smarty version Smarty-3.0.7, created on 2011-03-03 17:15:40
         compiled from "/opt/agcdr/public/../application/views/index/box_top10_dst.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12653004684d6fccbc7d1035-89647388%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2e1b7a6bba3fc591638b2e14091cfde9ff391734' => 
    array (
      0 => '/opt/agcdr/public/../application/views/index/box_top10_dst.tpl',
      1 => 1299171508,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12653004684d6fccbc7d1035-89647388',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<div class="title">Top 10 destinations</div>

<div class="content">



</div>
