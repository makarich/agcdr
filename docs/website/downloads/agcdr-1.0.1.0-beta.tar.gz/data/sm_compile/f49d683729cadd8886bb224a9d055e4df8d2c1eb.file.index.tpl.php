<?php /* Smarty version Smarty-3.0.7, created on 2011-03-16 14:11:01
         compiled from "/opt/agcdr/public/../application/views/search/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16559183724d80c4f5a275b3-24483904%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f49d683729cadd8886bb224a9d055e4df8d2c1eb' => 
    array (
      0 => '/opt/agcdr/public/../application/views/search/index.tpl',
      1 => 1300284659,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16559183724d80c4f5a275b3-24483904',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php $_template = new Smarty_Internal_Template('shared/htmlheader.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>

<h2>Advanced Search</h2>

<?php $_template = new Smarty_Internal_Template('search/form.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>

<p>Specify an advanced search of the caller detail record database using the form opposite.
You may add as many criteria as you wish. Records must match ALL your criteria if they are
to be included in the results, rather than just any of the criteria.</p>

<div style="clear: both;"></div>

<?php $_template = new Smarty_Internal_Template('shared/htmlfooter.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>
