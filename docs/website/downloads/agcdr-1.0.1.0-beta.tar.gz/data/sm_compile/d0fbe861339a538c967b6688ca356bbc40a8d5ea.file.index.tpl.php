<?php /* Smarty version Smarty-3.0.7, created on 2011-03-01 16:07:34
         compiled from "/opt/agcdr/application/views/index/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21456813274d6d19c667eb06-96399157%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd0fbe861339a538c967b6688ca356bbc40a8d5ea' => 
    array (
      0 => '/opt/agcdr/application/views/index/index.tpl',
      1 => 1298994394,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21456813274d6d19c667eb06-96399157',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php $_template = new Smarty_Internal_Template('shared/htmlheader.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>

<p>Index view.</p>

<?php $_template = new Smarty_Internal_Template('shared/htmlfooter.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>