<?php /* Smarty version Smarty-3.0.7, created on 2011-03-10 11:29:27
         compiled from "/opt/agcdr/public/../application/views/shared/navigation.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9484344684d78b61774a359-77924950%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b622c6a8bcc93ed98c87dc1d05ba9dfcc419aaa5' => 
    array (
      0 => '/opt/agcdr/public/../application/views/shared/navigation.tpl',
      1 => 1299756562,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9484344684d78b61774a359-77924950',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<ul id="navigation">
	<li <?php if ($_smarty_tpl->getVariable('controller')->value=="index"){?>class="selected"<?php }?>><a href="/">Overview</a></li>
	<li <?php if ($_smarty_tpl->getVariable('controller')->value=="reports"&&$_smarty_tpl->getVariable('action')->value=="month"){?>class="selected"<?php }?>><a href="/reports/month/">Month Report</a></li>
	<li <?php if ($_smarty_tpl->getVariable('controller')->value=="reports"&&$_smarty_tpl->getVariable('action')->value=="year"){?>class="selected"<?php }?>><a href="/reports/year/">Year Report</a></li>
	<li <?php if ($_smarty_tpl->getVariable('controller')->value=="search"&&$_smarty_tpl->getVariable('action')->value=="index"){?>class="selected"<?php }?>><a href="/search/index/">Advanced Search</a></li>
	<li <?php if ($_smarty_tpl->getVariable('controller')->value=="help"&&$_smarty_tpl->getVariable('action')->value=="index"){?>class="selected"<?php }?>><a href="/help/index/">Help & Support</a></li>
</ul>
