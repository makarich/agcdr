<?php /* Smarty version Smarty-3.0.7, created on 2011-03-10 17:42:44
         compiled from "/opt/agcdr/public/../application/views/shared/htmlheader.tpl" */ ?>
<?php /*%%SmartyHeaderCode:581550484d790d94ddb299-54921175%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5a1beca8d491a374caa596403ef591f0771eb5b3' => 
    array (
      0 => '/opt/agcdr/public/../application/views/shared/htmlheader.tpl',
      1 => 1299778952,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '581550484d790d94ddb299-54921175',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include '/opt/agcdr/application/libraries/Smarty-3.0.7/libs/plugins/modifier.date_format.php';
?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
	
<html lang="en">

<head>

	<title><?php if ($_smarty_tpl->getVariable('title')->value){?><?php echo $_smarty_tpl->getVariable('title')->value;?>
<?php }?></title>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="version" name="<?php echo @VERSION;?>
" />
	<link rel="SHORTCUT ICON" href="/favicon.ico" />
	
	<!-- General CSS and javascript -->
	<link rel="stylesheet" type="text/css" media="all" href="/css/stylesheet-min.css" />
	<link rel="stylesheet" type="text/css" media="print" href="/css/print-min.css" />
	<script type="text/javascript" src="/js/javascript-min.js"></script>
	<script type="text/javascript" src="/js/modernizr-1.6-min.js"></script>
	
	<!-- jQuery -->
	<link rel="stylesheet" type="text/css" href="/libraries/jquery-ui-1.8.10.custom/css/<?php echo @JQUI_THEME;?>
/jquery-ui-1.8.10.custom.css"/>
	<script type="text/javascript" src="/libraries/jquery-ui-1.8.10.custom/js/jquery-1.4.4.min.js"></script>
	<script type="text/javascript" src="/libraries/jquery-ui-1.8.10.custom/js/jquery-ui-1.8.10.custom.min.js"></script>
	<script type="text/javascript" src="/libraries/DataTables-1.7.5/media/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/js/jquery.dataTables.extensions-min.js"></script>
	<link rel="stylesheet" type="text/css" href="/css/demo_table_jui-min.css"/>

</head>

<body>

<?php if (defined("DEVINFO")){?><div id="devinfo" onclick="this.style.display='none';"><?php echo @DEVINFO;?>
</div><?php }?>

<div id="frame">

	<?php $_template = new Smarty_Internal_Template('shared/quicksearch.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>
	
	<?php $_template = new Smarty_Internal_Template('shared/serverselect.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>
	
	<h1><?php echo @LONG_TITLE;?>
</h1>
	
	<div id="clock"><?php echo smarty_modifier_date_format(time(),"%A %e %B %Y, %H:%M");?>
</div>
	
	<?php $_template = new Smarty_Internal_Template('shared/navigation.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>
