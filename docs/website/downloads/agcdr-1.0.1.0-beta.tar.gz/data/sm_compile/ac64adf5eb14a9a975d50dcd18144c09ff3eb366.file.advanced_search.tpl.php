<?php /* Smarty version Smarty-3.0.7, created on 2011-03-03 18:10:59
         compiled from "/opt/agcdr/public/../application/views/reports/advanced_search.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3410861484d6fd9b3c4e589-63629591%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ac64adf5eb14a9a975d50dcd18144c09ff3eb366' => 
    array (
      0 => '/opt/agcdr/public/../application/views/reports/advanced_search.tpl',
      1 => 1299173585,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3410861484d6fd9b3c4e589-63629591',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php $_template = new Smarty_Internal_Template('shared/htmlheader.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>



<?php $_template = new Smarty_Internal_Template('shared/htmlfooter.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>
