<?php /* Smarty version Smarty-3.0.7, created on 2011-03-16 14:10:39
         compiled from "/opt/agcdr/public/../application/views/search/results.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11576959754d80c4df99b322-01753883%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '62e5afc8a5ee120ca5ba9011499b36ee5acd730e' => 
    array (
      0 => '/opt/agcdr/public/../application/views/search/results.tpl',
      1 => 1300284633,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11576959754d80c4df99b322-01753883',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include '/opt/agcdr/application/libraries/Smarty-3.0.7/libs/plugins/modifier.date_format.php';
?><?php $_template = new Smarty_Internal_Template('shared/htmlheader.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>

<h2>Search Results</h2>

<?php if (count($_smarty_tpl->getVariable('results')->value)==0){?>

	<p class="ui-state-highlight ui-corner-all highlight">No CDRs matched your query.</p>

<?php }else{ ?>

	<table class="display" id="resultstable">
	
		<thead>
			<tr>
				<th>Unique ID</th>
				<th>Date</th>
				<th>Time</th>
				<th>Caller ID</th>
				<th>Source</th>
				<th>Destination</th>
				<th>Context</th>
				<th>Last app.</th>
				<th>Duration</th>
				<th>Billable</th>
				<th>Disposition</th>
			</tr>
		</thead>
		
		<tbody>
		
		<?php  $_smarty_tpl->tpl_vars['cdr'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['uniqueid'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('results')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['cdr']->key => $_smarty_tpl->tpl_vars['cdr']->value){
 $_smarty_tpl->tpl_vars['uniqueid']->value = $_smarty_tpl->tpl_vars['cdr']->key;
?>
		
			<tr>
				<td><a href="/cdr/view/?uid=<?php echo $_smarty_tpl->tpl_vars['uniqueid']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['uniqueid']->value;?>
</a></td>
				<td><?php echo smarty_modifier_date_format(strtotime($_smarty_tpl->tpl_vars['cdr']->value['calldate']),"%d/%m/%Y");?>
</td>
				<td><?php echo smarty_modifier_date_format(strtotime($_smarty_tpl->tpl_vars['cdr']->value['calldate']),"%H:%M:%S");?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['cdr']->value['clid'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['cdr']->value['src'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['cdr']->value['dst'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['cdr']->value['dcontext'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['cdr']->value['lastapp'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['cdr']->value['formatted_duration'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['cdr']->value['formatted_billsec'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['cdr']->value['disposition'];?>
</td>
			</tr>
		
		<?php }} ?>
		
		</tbody>
	
	</table>
	
	
	
	<script type="text/javascript">
	
	// apply DataTables plugin to results table
	$('#resultstable').dataTable({
		"bJQueryUI": true,
		"sPaginationType": "full_numbers",
		"bProcessing": true,
		"iDisplayLength": 25,
		"oLanguage": {
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ CDRs.",
			"sLengthMenu": 'Display <select><?php echo $_smarty_tpl->getVariable('menuoptions')->value;?>
</select> CDRs'
		},
                "aoColumns": [
			{"bSortable": false},
			{"bSortable": true, "sType": "uk_date"},
			{"bSortable": false},
			{"bSortable": true},
			{"bSortable": true},
			{"bSortable": true},
			{"bSortable": true},
			{"bSortable": true},
			{"bSortable": true},
			{"bSortable": true},
			{"bSortable": true}
		]
	});
	
	</script>
	
	

<?php }?>

<?php $_template = new Smarty_Internal_Template('search/form.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>

<p>You may alter your search parameters using the form opposite and re-submit your search.</p>

<div style="clear: both;"></div>

<?php $_template = new Smarty_Internal_Template('shared/htmlfooter.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>
