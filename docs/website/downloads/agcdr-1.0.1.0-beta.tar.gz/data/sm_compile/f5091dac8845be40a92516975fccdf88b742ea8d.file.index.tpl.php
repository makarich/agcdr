<?php /* Smarty version Smarty-3.0.7, created on 2011-03-03 16:46:30
         compiled from "/opt/agcdr/public/../application/views/index/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1592492944d6fc5e6b8aa86-54357307%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f5091dac8845be40a92516975fccdf88b742ea8d' => 
    array (
      0 => '/opt/agcdr/public/../application/views/index/index.tpl',
      1 => 1299170737,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1592492944d6fc5e6b8aa86-54357307',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php $_template = new Smarty_Internal_Template('shared/htmlheader.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>

<ul id="overviewgrid">
	<?php  $_smarty_tpl->tpl_vars['box'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('boxes')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['box']->key => $_smarty_tpl->tpl_vars['box']->value){
?>
		<li id="box_<?php echo $_smarty_tpl->tpl_vars['box']->value;?>
">Loading box <?php echo $_smarty_tpl->tpl_vars['box']->value;?>
 ...</li>
	<?php }} ?>
</ul>

<div style="clear: both;"></div>



<script type="text/javascript">
	
	$(function() {

		// create sortable grid
		$("#overviewgrid").sortable();
		$("#overviewgrid").disableSelection();

		// set box list
		var allBoxes = new Array(<?php echo $_smarty_tpl->getVariable('boxlist')->value;?>
);

		// load content into all boxes
		for (i=0; i<allBoxes.length; i++) {
			$("#box_"+allBoxes[i]).load('/index/box/?box='+allBoxes[i]);
		}
			
	});

</script>
	


<?php $_template = new Smarty_Internal_Template('shared/htmlfooter.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>