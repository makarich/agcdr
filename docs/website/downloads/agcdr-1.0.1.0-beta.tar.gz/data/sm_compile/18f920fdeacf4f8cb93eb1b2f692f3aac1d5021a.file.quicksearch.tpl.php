<?php /* Smarty version Smarty-3.0.7, created on 2011-03-11 10:28:11
         compiled from "/opt/agcdr/public/../application/views/shared/quicksearch.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6000964134d79f93b8fa2b1-25242701%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '18f920fdeacf4f8cb93eb1b2f692f3aac1d5021a' => 
    array (
      0 => '/opt/agcdr/public/../application/views/shared/quicksearch.tpl',
      1 => 1299839290,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6000964134d79f93b8fa2b1-25242701',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<form method="POST" action="/search/results/" onsubmit="return quickSearch();">

<div id="quicksearch">
	<input type="text" name="quicksearch" id="quicksearchstr" size="25" value="<?php echo $_smarty_tpl->getVariable('quicksearch')->value;?>
" placeholder="Quick search" />
</div>

</form>



<script type="text/javascript">

// check that quick search keywords are sane before submitting
function quickSearch() {
	
	var searchStr = document.getElementById('quicksearchstr').value;
	
	if (searchStr.length < 3) {
		alert("Quick search keyword must be at least three characters in length.");
		return false;
	}
	
	return true;
	
}

</script>


