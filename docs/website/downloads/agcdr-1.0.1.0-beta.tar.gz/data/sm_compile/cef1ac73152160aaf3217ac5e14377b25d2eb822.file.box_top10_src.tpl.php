<?php /* Smarty version Smarty-3.0.7, created on 2011-03-03 17:15:40
         compiled from "/opt/agcdr/public/../application/views/index/box_top10_src.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17333290174d6fccbc3d7452-40666387%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cef1ac73152160aaf3217ac5e14377b25d2eb822' => 
    array (
      0 => '/opt/agcdr/public/../application/views/index/box_top10_src.tpl',
      1 => 1299171508,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17333290174d6fccbc3d7452-40666387',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<div class="title">Top 10 sources</div>

<div class="content">



</div>
