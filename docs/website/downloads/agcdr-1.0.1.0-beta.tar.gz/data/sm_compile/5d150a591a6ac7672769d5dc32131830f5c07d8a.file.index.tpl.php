<?php /* Smarty version Smarty-3.0.7, created on 2011-03-16 14:16:20
         compiled from "/opt/agcdr/public/../application/views/help/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13725763154d80c634021173-93180700%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5d150a591a6ac7672769d5dc32131830f5c07d8a' => 
    array (
      0 => '/opt/agcdr/public/../application/views/help/index.tpl',
      1 => 1300284978,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13725763154d80c634021173-93180700',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php $_template = new Smarty_Internal_Template('shared/htmlheader.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>

<h2>Help & Support</h2>

<p>The help and support section is under construction. In the meantime please
see the HTML files within the "docs" directory for general information on
<?php echo @APP_TITLE;?>
</p>

<?php $_template = new Smarty_Internal_Template('shared/htmlfooter.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>