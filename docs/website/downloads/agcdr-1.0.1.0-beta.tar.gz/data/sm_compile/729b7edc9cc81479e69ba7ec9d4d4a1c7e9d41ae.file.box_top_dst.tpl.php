<?php /* Smarty version Smarty-3.0.7, created on 2011-03-04 15:31:53
         compiled from "/opt/agcdr/public/../application/views/index/box_top_dst.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10993211404d7105e9a2dcf7-23005545%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '729b7edc9cc81479e69ba7ec9d4d4a1c7e9d41ae' => 
    array (
      0 => '/opt/agcdr/public/../application/views/index/box_top_dst.tpl',
      1 => 1299252596,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10993211404d7105e9a2dcf7-23005545',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<div class="title">Top destinations</div>

<div class="content">

	<?php if (count($_smarty_tpl->getVariable('numbers')->value)>0){?>

		<table class="basicreport" width="100%">
		
			<thead><tr>
				<th>Destination</th>
				<th>Count</th>
			</tr></thead>
			
			<body>
			
			<?php  $_smarty_tpl->tpl_vars['count'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['number'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('numbers')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['count']->key => $_smarty_tpl->tpl_vars['count']->value){
 $_smarty_tpl->tpl_vars['number']->value = $_smarty_tpl->tpl_vars['count']->key;
?>
			
				<tr>
					<td><?php echo $_smarty_tpl->tpl_vars['number']->value;?>
</td>
					<td align="center"><?php echo $_smarty_tpl->tpl_vars['count']->value;?>
</td>
				</tr>
			
			<?php }} ?>
			
			</body>
		
		</table>
		
	<?php }else{ ?>
	
		<p>No statistics were returned by this overview.</p>
	
	<?php }?>

</div>
